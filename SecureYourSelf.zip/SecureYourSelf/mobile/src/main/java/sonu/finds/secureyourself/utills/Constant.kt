package sonu.finds.secureyourself.utills

class Constant {

    companion object {
        const val REQUEST_PERMISSION = 0
        const val SHARED_PREF_NAME = "my_shared_preff"
    }
}